#include <Wire.h>
#include <DHT.h>
#include <Adafruit_BMP085.h>
#include <LiquidCrystal_I2C.h>

#define SDA_PIN 8
#define SCL_PIN 9
#define DHT_PIN 18     // Pino alterado para GPIO 18
#define DHTTYPE DHT22  // Definição do tipo do sensor
#define LDR_PIN 5

DHT dht(DHT_PIN, DHTTYPE);
Adafruit_BMP085 bmp;
LiquidCrystal_I2C lcd(0x27, 20, 4);

void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);
  
  dht.begin(); // Inicializa o DHT22
  lcd.init();
  lcd.backlight();
  
  lcd.setCursor(0, 0);
  lcd.print("Iniciando...");
  delay(2000); // Tempo necessário para estabilização do DHT22
  lcd.clear();

  if (!bmp.begin()) {
    lcd.print("Erro no BMP180");
    Serial.println("BMP180 nao encontrado");
    while (true) delay(1000);
  }
}

void loop() {
  float temp = dht.readTemperature();
  float umid = dht.readHumidity();
  float press = bmp.readPressure() / 100.0;
  int luz = map(analogRead(LDR_PIN), 0, 4095, 0, 100);

  // Exibe Temperatura
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  if (isnan(temp)) {
    lcd.print("Erro   ");
  } else {
    lcd.print(temp, 1);
    lcd.print(" C  ");
  }

  // Exibe Umidade
  lcd.setCursor(0, 1);
  lcd.print("Umid: ");
  if (isnan(umid)) {
    lcd.print("Erro   ");
  } else {
    lcd.print(umid, 1);
    lcd.print(" %  ");
  }

  // Exibe Pressao
  lcd.setCursor(0, 2);
  lcd.print("Press: ");
  lcd.print(press, 1);
  lcd.print(" hPa ");

  // Exibe Luz
  lcd.setCursor(0, 3);
  lcd.print("Luz: ");
  lcd.print(luz);
  lcd.print(" % ");

  delay(2000);
}